---
date: 2021-02-18
title: Live Visuals @ Χωριό Παλιό
author: Aris Bezas from Guillermo Estrada
slug: live-visual-at-xoriopalio
tags:
  - p5.js
  - generative art
categories:
  - p5.js
---


{{<sketch "Simple Life" >}}
  {{<p5js-embed pixelated>}}
    {{<p5js-file simple-life.js>}}
  {{</p5js-embed>}}
{{</sketch>}}
^
