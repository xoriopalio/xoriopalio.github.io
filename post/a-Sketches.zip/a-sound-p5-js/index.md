---
date: 2021-02-18
title: p5.js sound
author: Aris Bezas from Guillermo Estrada
slug: sound-p5-js
tags:
  - p5.js
  - generative art
categories:
  - p5.js
---


{{<sketch "Sound-js" >}}
  {{<p5js-embed pixelated>}}
    {{<p5js-file sound-js.js>}}
  {{</p5js-embed>}}
{{</sketch>}}
