---
date: 2021-02-18
title: p5.js sound score
author: Aris Bezas from Guillermo Estrada
slug: sound-score
tags:
  - p5.js
  - generative art
categories:
  - p5.js
---


{{<sketch "Sound-js" >}}
  {{<p5js-embed pixelated>}}
    {{<p5js-file sound-score.js>}}
  {{</p5js-embed>}}
{{</sketch>}}
